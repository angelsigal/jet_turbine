using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class togglemethod : MonoBehaviour
{
    public GameObject jetComponent;
    private bool isVisible = true;

    public void toggle()
    {
        if(isVisible)
        {
            jetComponent.SetActive(false);
            isVisible = false;       
        }
        else 
        {
            jetComponent.SetActive(true);
            isVisible = true;   
        }
    }
    }
